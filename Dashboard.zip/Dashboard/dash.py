from flask import Flask, render_template, request
import joblib
import pickle
import pandas as pd

app = Flask(__name__)

#halaman home
@app.route('/')
def home():
    return render_template('Home.html')

#halaman dataset
@app.route('/database', methods=['POST', 'GET'])
def dataset():
    return render_template('Dataset.html')

# #halaman visualisasi
@app.route('/visualize', methods=['POST', 'GET'])
def visual():
    return render_template('Visualisation.html')

# #halaman input prediksi
@app.route('/predict', methods = ['POST', 'GET'])
def predict():
    return render_template('Prediction.html')


# #halaman hasil prediksi
@app.route('/result', methods = ['POST', 'GET'])
def result():
    if request.method == 'POST':
        input = request.form

        df_predict = pd.DataFrame({
            'neighbourhood_group':[input['Neighbourhood Group']],
            'neighbourhood':[input['Neighbourhood']],
            'latitude':[input['Latitude']],
            'longitude':[input['Longitude']],
            'room_type':[input['rt']],
            'minimum_nights':[input['minimum nights']],
            'number_of_reviews':[input['Number of Reviews']],
            'calculated_host_listings_count':[input['Calculated Host Listings Count']],
            'availability_365':[input['Availability 365']]
        })


        prediksi = model.predict(df_predict)[0]

        return render_template('Result.html',
            data=input, pred=prediksi)


if __name__ == '__main__':
    # model = joblib.load('model_joblib')

    filename = 'Model_Final.sav'
    model = pickle.load(open(filename,'rb'))

    app.run(debug=True)